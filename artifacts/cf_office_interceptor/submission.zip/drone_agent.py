"""Office Interceptor v1 — dead-reckoned pursuit of the detector boxes.

Frames and signs (all verified against swarm/core/moving_drone.py and measured in-sim):
  * world yaw increases CCW; body right = (sin yaw, -cos yaw).
  * sticks: lr>0 strafes RIGHT, fb>0 forward, ud>0 UP, yaw>0 turns CCW.
    A box right of centre (cx > 0.5) therefore needs a NEGATIVE yaw stick.
  * telemetry v_down (state[6]) is positive DOWN; world vz = -v_down.
  * dead-reckoned position: yaw is absolute (sin/cos in state[2:4]), so
    p += [c*vf + s*vr, s*vf - c*vr] * dt gives a world-aligned pseudo-position
    (~0.2-0.5 m drift over 60 s). Height (state[11]) is absolute to takeoff.
  * detector boxes are generated with the SAME camera the rgb uses: FOV 90+-2
    (we assume 90), eye = body + 0.13 fwd + 0.05 up, and box width/height are
    focal*0.18/d and focal*0.08/d -- so range = geometric mean of the two.
"""
import math
import numpy as np

DT = 1.0 / 50.0
IMG = 256.0
FOCAL = (IMG * 0.5) / math.tan(math.radians(90.0) * 0.5)   # 128 px at the 90 deg base FOV
TARGET_W_M = 0.18
TARGET_H_M = 0.08
DET_LATENCY_S = 0.04          # boxes describe a frame ~2 control steps old

CRUISE_ALT_M = 1.90           # middle of the target's 1.3-2.6 m band
CEIL_ALT_M = 2.55
FLOOR_ALT_M = 0.45
TAKEOFF_DONE_M = 1.80

YAW_GAIN = 1.8                # stick per rad of bearing error
UD_GAIN = 1.4                 # stick per metre of altitude error
FB_FULL_ALIGN_RAD = math.radians(30.0)
TERMINAL_RANGE_M = 1.3

TRACK_GATE_M = 1.4
TRACK_CONFIRM_HITS = 3
TRACK_CONFIRM_WINDOW_S = 2.0
TRACK_DROP_S = 2.5            # pursue prediction this long after last hit, then search
VEL_CAP = 2.2                 # target physical cap is ~1.95 m/s
GHOST_CAMP_S = 3.0            # this long inside 1.2 m without contact => ghost, blacklist
GHOST_BLACKLIST_S = 15.0
GHOST_BLACKLIST_R = 1.2

SEARCH_YAW_STICK = 0.45       # ~81 deg/s -> full revolution in ~4.4 s
SEARCH_SPIN_S = 9.0           # two revolutions before creeping
SEARCH_CREEP_S = 2.5
STUCK_SPEED = 0.15
STUCK_TIME_S = 1.5
BACKOFF_S = 0.8
PASS_BRAKE_S = 0.5
GOV_ERR_MAX = 2.4             # joint horizontal velocity-error cap when upright (m/s)
GOV_ERR_MIN = 0.8             # ...when the bank margin is gone
GOV_FREE_DEG = 20.0
GOV_LIMIT_DEG = 50.0          # env kills at 60; predict 0.18 s ahead from differentiated rpy
TILT_SOFT_DEG = 32.0          # above this scale translation down...
TILT_HARD_DEG = 45.0          # ...above this cut it entirely (env kills at 60)
BLOCK_SPEED = 0.25            # fb high but not moving => pinned against something
BLOCK_TILT_DEG = 18.0            # after a blown pass: kill momentum before the wall behind the target


def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


def rot_rpy(roll, pitch, yaw):
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.array([
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp, cp * sr, cp * cr]], dtype=np.float64)


class Track:
    __slots__ = ("p", "v", "hits", "born", "last", "spawn")
    def __init__(self, p, t):
        self.p = np.asarray(p, dtype=np.float64)
        self.v = np.zeros(3)
        self.hits = 1
        self.born = t
        self.last = t
        self.spawn = self.p.copy()

    def predict(self, t):
        return self.p + self.v * max(0.0, t - self.last)

    def update(self, meas, t):
        dt = max(t - self.last, 1e-3)
        innov = np.asarray(meas, dtype=np.float64) - self.predict(t)
        self.p = self.predict(t) + 0.55 * innov
        self.v = self.v + (0.35 / dt) * innov
        n = float(np.linalg.norm(self.v))
        if n > VEL_CAP:
            self.v *= VEL_CAP / n
        self.hits += 1
        self.last = t


class DroneFlightController:

    def __init__(self):
        self.reset()

    def reset(self):
        self.t = 0.0
        self.p = np.zeros(3)              # dead-reckoned world-aligned position
        self.prev_det_age = None
        self.tracks = []
        self.mode = "TAKEOFF"
        self.search_t0 = 0.0
        self.camp_t0 = None
        self.blacklist = []               # (xy, expiry_t)
        self.slow_since = None
        self.backoff_until = -1.0
        self.speed_ema = 0.0
        self.dist_hist = []
        self.brake_until = -1.0
        self.pursue_t0 = 0.0
        self.prev_rpy = None

    # ------------------------------------------------------------------ #
    def act(self, observation):
        st = np.asarray(observation["state"], dtype=np.float64).reshape(-1)
        self.t += DT
        t = self.t

        pitch, roll = float(st[0]), float(st[1])
        yaw = math.atan2(float(st[2]), float(st[3]))
        c, s = math.cos(yaw), math.sin(yaw)
        vf, vr, vdn = float(st[4]), float(st[5]), float(st[6])
        height = float(st[11])
        valid = float(st[14]) > 0.5

        # dead reckoning (ZOH on the 10 Hz packets; z comes straight from fused height)
        if valid:
            self.p[0] += (c * vf + s * vr) * DT
            self.p[1] += (s * vf - c * vr) * DT
        self.p[2] = height
        self.speed_ema += 0.06 * (math.hypot(vf, vr) - self.speed_ema)

        # ---------------- detector ingestion (new frame = age reset) ----
        det_age = float(st[16])
        new_frame = self.prev_det_age is not None and det_age < self.prev_det_age - 1e-9
        self.prev_det_age = det_age
        n_boxes = int(round(float(st[15])))
        if new_frame and n_boxes > 0:
            R = rot_rpy(roll, pitch, yaw)
            cam = self.p + R @ np.array([0.13, 0.0, 0.05])
            t_meas = t - DET_LATENCY_S
            for b in range(2):
                cx, cy, w, h, conf = st[17 + 5 * b:22 + 5 * b]
                if conf <= 0.0 or w <= 0.0 or h <= 0.0:
                    continue
                d_w = FOCAL * TARGET_W_M / max(float(w) * IMG, 1e-6)
                d_h = FOCAL * TARGET_H_M / max(float(h) * IMG, 1e-6)
                rng = math.sqrt(max(d_w, 0.05) * max(d_h, 0.05))
                u = (float(cx) - 0.5) * IMG
                v = (float(cy) - 0.5) * IMG
                body_ray = np.array([1.0, -u / FOCAL, -v / FOCAL])
                body_ray /= np.linalg.norm(body_ray)
                meas = cam + (R @ body_ray) * rng
                self._ingest(meas, t_meas)

        # prune tracks and blacklist
        self.tracks = [k for k in self.tracks if t - k.last < 6.0]
        self.blacklist = [(xy, e) for (xy, e) in self.blacklist if e > t]

        target = self._confirmed(t)

        # ---------------- behaviour ------------------------------------ #
        lr = fb = ud = yw = 0.0

        if self.mode == "TAKEOFF":
            ud = max(-0.5, min(0.5, 1.2 * (CRUISE_ALT_M - height)))
            if abs(height - CRUISE_ALT_M) < 0.25 and abs(vdn) < 0.4:
                self.mode = "SEARCH"
                self.search_t0 = t
        elif target is None:
            if self.mode != "SEARCH":
                self.mode = "SEARCH"
                self.search_t0 = t
            ud = self._alt_stick(height, CRUISE_ALT_M)
            phase = (t - self.search_t0) % (SEARCH_SPIN_S + SEARCH_CREEP_S)
            if phase < SEARCH_SPIN_S:
                yw = SEARCH_YAW_STICK
            else:
                fb = 0.30                      # short bounded creep to a new vantage
        else:
            if self.mode != "PURSUE":
                self.pursue_t0 = t
            self.mode = "PURSUE"
            tp = target.predict(t)
            rel = tp - self.p
            dist_xy = math.hypot(rel[0], rel[1])
            dist3 = float(np.linalg.norm(rel))
            bearing = math.atan2(rel[1], rel[0])
            az_err = wrap(bearing - yaw)       # >0 = target CCW/left of nose
            yw = max(-0.95, min(0.95, YAW_GAIN * az_err))
            ud = self._alt_stick(height, float(tp[2]))
            # blown-pass containment: distance opening at close range => momentum
            # is carrying us past the target (and into whatever is behind it)
            self.dist_hist.append((t, dist3))
            self.dist_hist = [(a, b) for (a, b) in self.dist_hist if t - a < 0.30]
            opening = (len(self.dist_hist) >= 3
                       and dist3 - self.dist_hist[0][1] > 0.06
                       and self.dist_hist[0][1] < 1.1)
            if opening and t > self.brake_until:
                self.brake_until = t + PASS_BRAKE_S
            if t < self.brake_until:
                fb = 0.25 * vf / 3.0           # decay the velocity target: decel without blind reverse
            elif dist3 < TERMINAL_RANGE_M:
                fb = min(1.0, 0.45 + 0.40 * dist3)   # fast enough to catch, shallow enough to stop
            else:
                align = max(0.0, math.cos(az_err))
                if abs(az_err) > math.radians(75.0):
                    fb = 0.05
                else:
                    fb = min(1.0, 0.30 + 0.35 * dist_xy) * align
            ramp = min(1.0, 0.30 + (t - self.pursue_t0) / 0.8)
            fb = min(fb, ramp)
            # ghost camp watch: sitting on the "target" without contact
            if dist3 < 1.2:
                if self.camp_t0 is None:
                    self.camp_t0 = t
                elif t - self.camp_t0 > GHOST_CAMP_S:
                    self.blacklist.append((tp[:2].copy(), t + GHOST_BLACKLIST_S))
                    self.tracks = [k for k in self.tracks if k is not target]
                    self.camp_t0 = None
                    self.mode = "SEARCH"
                    self.search_t0 = t
            else:
                self.camp_t0 = None

        # ---------------- safety / recovery ----------------------------- #
        if t < self.backoff_until:
            fb, lr = 0.0, 0.0
            yw = 0.65
            ud = max(ud, 0.12)
        else:
            if fb > 0.4 and self.speed_ema < STUCK_SPEED and self.mode != "TAKEOFF":
                if self.slow_since is None:
                    self.slow_since = t
                elif t - self.slow_since > STUCK_TIME_S:
                    self.backoff_until = t + BACKOFF_S
                    self.slow_since = None
            else:
                self.slow_since = None
        # ---- attitude & wind-up protection (the last word on translation) ----
        tilt_deg = math.degrees(max(abs(pitch), abs(roll)))
        speed_inst = math.hypot(vf, vr)
        # pinned: commanding forward, going nowhere, starting to bank
        if fb > 0.4 and speed_inst < BLOCK_SPEED and tilt_deg > BLOCK_TILT_DEG:
            fb = 0.0
            self.backoff_until = max(self.backoff_until, t + 0.5)
        # margin-scaled JOINT governor (UID_4's shape): the allowed velocity-error
        # vector shrinks with predicted tilt; per-channel caps miss combined demands
        if self.prev_rpy is not None:
            rr = (roll - self.prev_rpy[0]) / DT
            pr = (pitch - self.prev_rpy[1]) / DT
        else:
            rr = pr = 0.0
        self.prev_rpy = (roll, pitch)
        tilt_pred = math.degrees(max(
            abs(roll) + max(0.0, rr * math.copysign(1.0, roll)) * 0.18,
            abs(pitch) + max(0.0, pr * math.copysign(1.0, pitch)) * 0.18))
        frac = max(0.0, min(1.0, (GOV_LIMIT_DEG - max(tilt_pred, math.degrees(max(abs(roll), abs(pitch))))) / (GOV_LIMIT_DEG - GOV_FREE_DEG)))
        allow = GOV_ERR_MIN + (GOV_ERR_MAX - GOV_ERR_MIN) * frac
        ef, er = 3.0 * fb - vf, 3.0 * lr - vr
        en = math.hypot(ef, er)
        if en > allow:
            ef *= allow / en; er *= allow / en
            fb, lr = (vf + ef) / 3.0, (vr + er) / 3.0
        if en > 1.2 and self.mode != "TAKEOFF":
            ud = max(-0.3, min(0.3, ud))   # attitude before altitude while accelerating
        # centripetal coupling: hard yaw at speed banks the frame
        yw_cap = 0.35 + 0.9 / max(speed_inst, 0.45)
        yw = max(-min(0.95, yw_cap), min(min(0.95, yw_cap), yw))
        if tilt_deg > TILT_HARD_DEG:
            # zero-ERROR recovery: freeze the velocity target at what we are doing —
            # commanding zero velocity at speed is itself a max-bank demand
            fb, lr, ud = vf / 3.0, vr / 3.0, -vdn / 6.0
        elif tilt_deg > TILT_SOFT_DEG:
            k = 1.0 - (tilt_deg - TILT_SOFT_DEG) / (TILT_HARD_DEG - TILT_SOFT_DEG)
            fb = vf / 3.0 + (fb - vf / 3.0) * k
            lr = vr / 3.0 + (lr - vr / 3.0) * k
        alt_cap = 2.62 if (self.mode == "PURSUE" and self.camp_t0 is None and target is not None
                            and float(np.linalg.norm(target.predict(t) - self.p)) < TERMINAL_RANGE_M) else 2.42
        if height > alt_cap - 0.15:
            ud = min(ud, max(-0.65, 1.6 * (alt_cap - height)))
        if height < FLOOR_ALT_M and self.mode != "TAKEOFF":
            ud = max(ud, 0.25)

        out = np.array([lr, fb, ud, yw], dtype=np.float32)
        return np.clip(out, -1.0, 1.0)

    # ------------------------------------------------------------------ #
    def _alt_stick(self, z, z_ref):
        return max(-0.6, min(0.6, UD_GAIN * (z_ref - z)))

    def _ingest(self, meas, t):
        for (xy, _e) in self.blacklist:
            if math.hypot(meas[0] - xy[0], meas[1] - xy[1]) < GHOST_BLACKLIST_R:
                return
        best, best_d = None, 1e9
        for k in self.tracks:
            d = float(np.linalg.norm(k.predict(t) - meas))
            if d < best_d:
                best, best_d = k, d
        gate = TRACK_GATE_M + 0.5 * (t - best.last) if best is not None else 0.0
        if best is not None and best_d < gate:
            best.update(meas, t)
        else:
            self.tracks.append(Track(meas, t))
            if len(self.tracks) > 6:
                self.tracks.sort(key=lambda k: (k.hits, k.last))
                self.tracks.pop(0)

    def _confirmed(self, t):
        live = [k for k in self.tracks
                if k.hits >= TRACK_CONFIRM_HITS
                and t - k.last < TRACK_DROP_S
                and (t - k.born) < 1e9]
        if not live:
            return None
        live.sort(key=lambda k: (-(k.last), -k.hits))
        return live[0]
